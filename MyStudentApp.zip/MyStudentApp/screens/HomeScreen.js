import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import axios from 'axios';

function HomeScreen({ navigation, route }) {
  var [students, setStudents] = useState([]);
  var [loading, setLoading] = useState(true);
  var [error, setError] = useState(false);
  var [refreshing, setRefreshing] = useState(false);

  function loadStudents() {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then(function (response) {
        setStudents(response.data);
        setLoading(false);
        setRefreshing(false);
      })
      .catch(function () {
        setError(true);
        setLoading(false);
        setRefreshing(false);
      });
  }

  useEffect(function () {
    loadStudents();
  }, []);

  useEffect(function () {
    if (route.params?.newStudent) {
      var newStudent = route.params.newStudent;
      setStudents(function (prev) {
        return [newStudent, ...prev];
      });
    }
  }, [route.params?.newStudent]);

  function onRefresh() {
    setRefreshing(true);
    loadStudents();
  }

  function renderStudent({ item }) {
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={function () {
          navigation.navigate('StudentDetailScreen', { student: item });
        }}
      >
        <Text style={styles.studentName}>{item.name}</Text>
        <Text style={styles.studentInfo}>Email: {item.email}</Text>
        <Text style={styles.studentInfo}>Phone: {item.phone}</Text>
      </TouchableOpacity>
    );
  }

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2e86de" />
        <Text style={styles.loadingText}>Please wait...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>Could not load students.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.addButton}
          onPress={function () { navigation.navigate('AddStudentScreen'); }}
        >
          <Text style={styles.buttonText}>Add Student</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.scrollButton}
          onPress={function () {
            navigation.navigate('ScrollInfoScreen', {
              studentName: 'Guest',
              companyName: 'N/A',
            });
          }}
        >
          <Text style={styles.buttonText}>Scroll Demo</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={students}
        keyExtractor={function (item) { return item.id.toString(); }}
        renderItem={renderStudent}
        refreshing={refreshing}
        onRefresh={onRefresh}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 12,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 15,
    color: '#555555',
  },
  errorText: {
    fontSize: 15,
    color: 'red',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  addButton: {
    backgroundColor: '#2e86de',
    padding: 10,
    borderRadius: 8,
    flex: 1,
    marginRight: 6,
    alignItems: 'center',
  },
  scrollButton: {
    backgroundColor: '#576574',
    padding: 10,
    borderRadius: 8,
    flex: 1,
    marginLeft: 6,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  studentName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2e86de',
    marginBottom: 4,
  },
  studentInfo: {
    fontSize: 13,
    color: '#555555',
    marginTop: 2,
  },
});

export default HomeScreen;