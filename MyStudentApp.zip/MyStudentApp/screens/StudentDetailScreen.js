import React, { useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
} from 'react-native';

function StudentDetailScreen({ route, navigation }) {
  var student = route.params.student;

  useEffect(function () {
    navigation.setOptions({ title: student.name });
  }, [navigation, student.name]);

  return (
    <ScrollView style={styles.container}>

      <StatusBar barStyle="dark-content" backgroundColor="#2e86de" />

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Basic Information</Text>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Name</Text>
          <Text style={styles.infoValue}>{student.name}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Username</Text>
          <Text style={styles.infoValue}>{student.username}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Email</Text>
          <Text style={styles.infoValue}>{student.email}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Phone</Text>
          <Text style={styles.infoValue}>{student.phone}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Website</Text>
          <Text style={styles.infoValue}>{student.website}</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Address and Company</Text>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>City</Text>
          <Text style={styles.infoValue}>{student.address.city}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Company</Text>
          <Text style={styles.infoValue}>{student.company.name}</Text>
        </View>
      </View>

      <Pressable
        style={styles.demoButton}
        onPress={function () {
          navigation.navigate('ScrollInfoScreen', {
            studentName: student.name,
            companyName: student.company.name,
          });
        }}
      >
        <Text style={styles.demoButtonText}>View Scroll Demo</Text>
      </Pressable>

      <TouchableOpacity
        style={styles.backButton}
        onPress={function () { navigation.goBack(); }}
      >
        <Text style={styles.backButtonText}>Back to List</Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 14,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 14,
    elevation: 3,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#2e86de',
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#eeeeee',
    paddingBottom: 6,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  infoLabel: {
    fontSize: 13,
    color: '#888888',
    fontWeight: 'bold',
    flex: 1,
  },
  infoValue: {
    fontSize: 13,
    color: '#333333',
    flex: 2,
    textAlign: 'right',
  },
  demoButton: {
    backgroundColor: '#576574',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  demoButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 15,
  },
  backButton: {
    backgroundColor: '#2e86de',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 30,
  },
  backButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 15,
  },
});

export default StudentDetailScreen;