import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

var skills = ['React Native', 'JavaScript', 'HTML', 'CSS', 'Node.js', 'Git'];
var projects = ['Student App', 'Weather App', 'Todo App', 'Chat App'];

function ScrollInfoScreen({ route, navigation }) {
  var studentName = route.params?.studentName || 'Student';
  var companyName = route.params?.companyName || 'Company';

  return (
    <ScrollView style={styles.container}>

      <View style={styles.greetingCard}>
        <Text style={styles.greetingName}>Hello, {studentName}</Text>
        <Text style={styles.greetingCompany}>Works at {companyName}</Text>
      </View>

      <Text style={styles.sectionTitle}>About</Text>
      <View style={styles.aboutCard}>
        <Text style={styles.aboutText}>
          This is my AWP assignment completed from my village. This screen
          uses an outer vertical ScrollView for the whole page, and inner
          horizontal ScrollViews for Skills and Projects sections.
        </Text>
        <Text style={styles.aboutText}>
          nestedScrollEnabled is set to true on inner ScrollViews so Android
          does not block horizontal scrolling inside a vertical ScrollView.
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Skills</Text>
      <ScrollView
        horizontal={true}
        nestedScrollEnabled={true}
        showsHorizontalScrollIndicator={false}
        style={styles.horizontalScroll}
      >
        {skills.map(function (skill, index) {
          return (
            <View key={index} style={styles.badgeCard}>
              <Text style={styles.badgeText}>{skill}</Text>
            </View>
          );
        })}
      </ScrollView>

      <Text style={styles.sectionTitle}>Projects</Text>
      <ScrollView
        horizontal={true}
        nestedScrollEnabled={true}
        showsHorizontalScrollIndicator={false}
        style={styles.horizontalScroll}
      >
        {projects.map(function (project, index) {
          return (
            <View key={index} style={styles.projectCard}>
              <Text style={styles.projectName}>{project}</Text>
              <Text style={styles.projectStatus}>Completed</Text>
            </View>
          );
        })}
      </ScrollView>

      <TouchableOpacity
        style={styles.homeButton}
        onPress={function () { navigation.popToTop(); }}
      >
        <Text style={styles.homeButtonText}>Back to Home</Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 14,
  },
  greetingCard: {
    backgroundColor: '#2e86de',
    borderRadius: 10,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
  },
  greetingName: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  greetingCompany: {
    color: '#d6eaf8',
    fontSize: 14,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 10,
    marginTop: 6,
  },
  aboutCard: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 3,
  },
  aboutText: {
    fontSize: 14,
    color: '#555555',
    lineHeight: 22,
    marginBottom: 8,
  },
  horizontalScroll: {
    marginBottom: 16,
  },
  badgeCard: {
    backgroundColor: '#2e86de',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 18,
    marginRight: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 13,
  },
  projectCard: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 16,
    marginRight: 12,
    width: 130,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  projectName: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#333333',
    textAlign: 'center',
  },
  projectStatus: {
    fontSize: 11,
    color: '#27ae60',
    marginTop: 6,
  },
  homeButton: {
    backgroundColor: '#2e86de',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 40,
  },
  homeButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 15,
  },
});

export default ScrollInfoScreen;