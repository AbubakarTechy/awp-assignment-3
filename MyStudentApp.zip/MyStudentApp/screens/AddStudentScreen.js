import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Switch,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
} from 'react-native';

function AddStudentScreen({ navigation }) {
  var [name, setName] = useState('');
  var [email, setEmail] = useState('');
  var [phone, setPhone] = useState('');
  var [city, setCity] = useState('');
  var [isActive, setIsActive] = useState(true);

  function handleSubmit() {
    if (name == '' || email == '' || phone == '' || city == '') {
      Alert.alert('Error', 'Please fill all fields before submitting.');
      return;
    }

    var newStudent = {
      id: Math.random(),
      name: name,
      email: email,
      phone: phone,
      username: name,
      website: 'N/A',
      address: { city: city },
      company: { name: 'New Company' },
      isActive: isActive,
    };

    navigation.navigate('HomeScreen', { newStudent: newStudent });
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView style={styles.container}>

        <Text style={styles.label}>Name</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter student name"
          value={name}
          onChangeText={function (text) { setName(text); }}
        />

        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter email address"
          value={email}
          onChangeText={function (text) { setEmail(text); }}
          keyboardType="email-address"
        />

        <Text style={styles.label}>Phone</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter phone number"
          value={phone}
          onChangeText={function (text) { setPhone(text); }}
          keyboardType="phone-pad"
        />

        <Text style={styles.label}>City</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter city"
          value={city}
          onChangeText={function (text) { setCity(text); }}
        />

        <View style={styles.switchRow}>
          <Text style={styles.label}>Active Student</Text>
          <Switch
            value={isActive}
            onValueChange={function (value) { setIsActive(value); }}
            trackColor={{ false: '#cccccc', true: '#2e86de' }}
          />
        </View>

        <Text style={styles.statusText}>
          Status: {isActive ? 'Active' : 'Inactive'}
        </Text>

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Add Student</Text>
        </TouchableOpacity>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
    marginTop: 14,
    marginBottom: 4,
  },
  input: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#cccccc',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: '#333333',
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  statusText: {
    color: '#2e86de',
    fontWeight: 'bold',
    marginTop: 6,
    fontSize: 13,
  },
  submitButton: {
    backgroundColor: '#2e86de',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 40,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AddStudentScreen;