import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './screens/HomeScreen';
import AddStudentScreen from './screens/AddStudentScreen';
import StudentDetailScreen from './screens/StudentDetailScreen';
import ScrollInfoScreen from './screens/ScrollInfoScreen';

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="HomeScreen">
        <Stack.Screen
          name="HomeScreen"
          component={HomeScreen}
          options={{ title: 'Student List' }}
        />
        <Stack.Screen
          name="AddStudentScreen"
          component={AddStudentScreen}
          options={{ title: 'Add Student' }}
        />
        <Stack.Screen
          name="StudentDetailScreen"
          component={StudentDetailScreen}
          options={{ title: 'Student Detail' }}
        />
        <Stack.Screen
          name="ScrollInfoScreen"
          component={ScrollInfoScreen}
          options={{ title: 'Scroll Demo' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;